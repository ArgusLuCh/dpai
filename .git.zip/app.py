from flask import Flask, render_template, request, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
from pathlib import Path
import os

DB = Path("actuaciones.db")

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not DB.exists():
        conn = get_db()
        conn.execute('''CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre_usuario TEXT UNIQUE NOT NULL,
            contrasena TEXT NOT NULL,
            nombre_completo TEXT,
            es_admin INTEGER DEFAULT 0
        )''')
        conn.execute('''CREATE TABLE actuaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            numero_actuacion TEXT NOT NULL,
            fecha_lugar TEXT NOT NULL,
            dependencia TEXT,
            fecha_avocamiento TEXT,
            damnificado TEXT NOT NULL,
            acusado TEXT NOT NULL,
            relato TEXT,
            estado TEXT,
            color TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES usuarios(id)
        )''')
        conn.commit()
        conn.close()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'tu_clave_secreta_aqui_cambiar_produccion'

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class Usuario(UserMixin):
    def __init__(self, id, nombre_usuario, nombre_completo, es_admin=False):
        self.id = id
        self.nombre_usuario = nombre_usuario
        self.nombre_completo = nombre_completo
        self.es_admin = es_admin

@login_manager.user_loader
def load_user(user_id):
    conn = get_db()
    user = conn.execute('SELECT * FROM usuarios WHERE id=?', (user_id,)).fetchone()
    conn.close()
    if user:
        return Usuario(user['id'], user['nombre_usuario'], user['nombre_completo'], user['es_admin'])
    return None

STATUSES = {
    'elevada': 'Elevada',
    'elevada_con_acusado': 'Elevada (con acusado)',
    'en_investigacion': 'En investigación',
    'elevada_a_fiscalia': 'Elevada a Fiscalía',
    'elevada_a_otra_dependencia': 'Elevada a otra dependencia'
}
COLORS = ['verde', 'amarillo', 'rojo']

init_db()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nombre_usuario = request.form.get('nombre_usuario')
        contrasena = request.form.get('contrasena')
        
        conn = get_db()
        user_data = conn.execute('SELECT * FROM usuarios WHERE nombre_usuario=?', (nombre_usuario,)).fetchone()
        conn.close()
        
        if user_data and check_password_hash(user_data['contrasena'], contrasena):
            user = Usuario(user_data['id'], user_data['nombre_usuario'], user_data['nombre_completo'], user_data['es_admin'])
            login_user(user)
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Usuario o contraseña incorrectos')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/registrar', methods=['GET', 'POST'])
def registrar():
    if request.method == 'POST':
        nombre_usuario = request.form.get('nombre_usuario')
        contrasena = request.form.get('contrasena')
        nombre_completo = request.form.get('nombre_completo')
        
        if not nombre_usuario or not contrasena:
            return render_template('registrar.html', error='Usuario y contraseña requeridos')
        
        conn = get_db()
        try:
            conn.execute('INSERT INTO usuarios (nombre_usuario, contrasena, nombre_completo) VALUES (?,?,?)',
                (nombre_usuario, generate_password_hash(contrasena), nombre_completo))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('registrar.html', error='El usuario ya existe')
    
    return render_template('registrar.html')

@app.route('/')
@login_required
def index():
    conn = get_db()
    busqueda = request.args.get('q', '').strip()
    
    if current_user.es_admin:
        if busqueda:
            # Búsqueda general en múltiples campos
            patron = f'%{busqueda}%'
            filas = conn.execute('''SELECT a.*, u.nombre_completo FROM actuaciones a 
                                   JOIN usuarios u ON a.user_id=u.id 
                                   WHERE a.numero_actuacion LIKE ? 
                                      OR a.damnificado LIKE ? 
                                      OR a.acusado LIKE ? 
                                      OR a.dependencia LIKE ?
                                   ORDER BY a.created_at DESC''', 
                                (patron, patron, patron, patron)).fetchall()
        else:
            filas = conn.execute('SELECT a.*, u.nombre_completo FROM actuaciones a JOIN usuarios u ON a.user_id=u.id ORDER BY a.created_at DESC').fetchall()
        
        # Agrupar actuaciones por usuario (nombre_completo)
        actuaciones_por_usuario = {}
        for fila in filas:
            nombre_usuario = fila['nombre_completo']
            if nombre_usuario not in actuaciones_por_usuario:
                actuaciones_por_usuario[nombre_usuario] = []
            actuaciones_por_usuario[nombre_usuario].append(fila)
    else:
        filas = conn.execute('SELECT a.*, u.nombre_completo FROM actuaciones a JOIN usuarios u ON a.user_id=u.id WHERE a.user_id=? ORDER BY a.created_at DESC', (current_user.id,)).fetchall()
        actuaciones_por_usuario = {}
    
    conn.close()
    return render_template('index.html', actuaciones=filas, actuaciones_por_usuario=actuaciones_por_usuario, statuses=STATUSES, colors=COLORS, es_admin=current_user.es_admin, busqueda=busqueda)

@app.route('/add', methods=['POST'])
@login_required
def add():
    numero_actuacion = request.form.get('numero_actuacion','').strip()
    fecha_lugar = request.form.get('fecha_lugar','').strip()
    dependencia = request.form.get('dependencia','').strip()
    fecha_avocamiento = request.form.get('fecha_avocamiento','').strip()
    damnificado = request.form.get('damnificado','').strip()
    acusado = request.form.get('acusado','').strip()
    relato = request.form.get('relato','').strip()
    estado = request.form.get('estado','')
    if estado is not None:
        estado = estado.strip()
    color = request.form.get('color','').strip()
    # Fallback automático: si no se indicó estado, asignar 'en_investigacion'
    if not estado:
        estado = 'en_investigacion'
    if numero_actuacion and fecha_lugar and damnificado and acusado:
        conn = get_db()
        conn.execute('INSERT INTO actuaciones (user_id, numero_actuacion, fecha_lugar, dependencia, fecha_avocamiento, damnificado, acusado, relato, estado, color, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            (current_user.id, numero_actuacion, fecha_lugar, dependencia, fecha_avocamiento, damnificado, acusado, relato, estado, color, datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
    return redirect(url_for('index'))

@app.route('/edit/<int:id>', methods=['GET','POST'])
@login_required
def edit(id):
    conn = get_db()
    fila = conn.execute('SELECT * FROM actuaciones WHERE id=?', (id,)).fetchone()
    
    if not fila:
        conn.close()
        return redirect(url_for('index'))
    
    if fila['user_id'] != current_user.id and not current_user.es_admin:
        conn.close()
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        if current_user.es_admin:
            estado = request.form.get('estado')
            if estado is not None:
                estado = estado.strip()
            color = request.form.get('color')
            if color is not None:
                color = color.strip()
            # Fallback automático: si el admin dejó el estado vacío, asignar 'en_investigacion'
            if not estado:
                estado = 'en_investigacion'
            conn.execute('UPDATE actuaciones SET estado=?, color=? WHERE id=?', (estado, color, id))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    
    conn.close()
    return render_template('edit.html', a=fila, statuses=STATUSES, colors=COLORS, es_admin=current_user.es_admin)

@app.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    conn = get_db()
    fila = conn.execute('SELECT user_id FROM actuaciones WHERE id=?', (id,)).fetchone()
    
    if fila and (fila['user_id'] == current_user.id or current_user.es_admin):
        conn.execute('DELETE FROM actuaciones WHERE id=?', (id,))
        conn.commit()
    
    conn.close()
    return redirect(url_for('index'))

@app.route('/crear-admin', methods=['GET', 'POST'])
def crear_admin():
    conn = get_db()
    admin_exists = conn.execute('SELECT COUNT(*) as cnt FROM usuarios WHERE es_admin=1').fetchone()
    conn.close()
    
    if admin_exists['cnt'] >= 3:
        return "Ya existen 3 administradores", 403
    
    if request.method == 'POST':
        nombre_usuario = request.form.get('nombre_usuario')
        contrasena = request.form.get('contrasena')
        nombre_completo = request.form.get('nombre_completo', nombre_usuario)
        
        if not nombre_usuario or not contrasena:
            return render_template('crear_admin.html', error='Usuario y contraseña requeridos')
        
        conn = get_db()
        try:
            conn.execute('INSERT INTO usuarios (nombre_usuario, contrasena, nombre_completo, es_admin) VALUES (?,?,?,1)',
                (nombre_usuario, generate_password_hash(contrasena), nombre_completo))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('crear_admin.html', error='El usuario ya existe')
    
    return render_template('crear_admin.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)