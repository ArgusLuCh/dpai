# Registro de Actuaciones

Aplicación Flask para registrar actuaciones por usuario, modificar su estado y marcar colores (verde/amarillo/rojo).

Incluye rol de **Administrador** que puede ver y editar todas las actuaciones de todos los usuarios.

## Instrucciones rápidas (Windows PowerShell):

```powershell
python -m pip install -r requirements.txt
python app.py
```

## Acceso local:
- Abrir en la misma máquina: http://127.0.0.1:5000

## Acceso desde otras computadoras:
La aplicación ahora está disponible para toda la red local. Desde otra máquina, accede a:

```
http://<IP_DEL_SERVIDOR>:5000
```

**Para obtener la IP del servidor (en PowerShell):**
```powershell
ipconfig
```
Busca la dirección IPv4 (ej: 192.168.1.100)

**Desde otra máquina (cualquier navegador):**
```
http://192.168.1.100:5000
```

## Uso:

### Primera vez - Crear Administradores:

1. Abre http://127.0.0.1:5000/crear-admin
2. Crea la primera cuenta de administrador
3. Opcionalmente, puedes crear dos cuentas de administrador más en `/crear-admin` (hasta 3 en total)
4. Inicia sesión con una de esas cuentas

### Usuarios normales:

1. En `/login`, haz clic en "Registrate aquí"
2. Crea tu cuenta de actuario
3. Inicia sesión y carga tus actuaciones

### Como Administrador:

- Ves **todas** las actuaciones de todos los usuarios
- Puedes **editar** estado y color de cualquier actuación
- Puedes **borrar** cualquier actuación
- Se muestra el nombre del actuario que creó cada actuación

### Como Actuario:

- Solo ves tus propias actuaciones
- Puedes **ver** y **borrar** solo las tuyas
- Campos que puedes cargar:
  - Número de actuación
  - Fecha y lugar del hecho
  - Dependencia
  - Fecha de avocamiento (opcional)
  - Damnificado
  - Acusado
  - Relato (breve descripción)
  - **Estado y Color**: NO se asignan automáticamente. Los tiene que asignar un administrador

## Archivos principales:
- [app.py](app.py) - Lógica principal con autenticación y roles
- [templates/base.html](templates/base.html) - Plantilla base
- [templates/login.html](templates/login.html) - Login
- [templates/crear_admin.html](templates/crear_admin.html) - Crear administrador
- [templates/registrar.html](templates/registrar.html) - Registro de actuarios
- [templates/index.html](templates/index.html) - Listado y crear actuaciones
- [templates/edit.html](templates/edit.html) - Editar estado/color
- [static/style.css](static/style.css) - Estilos CSS

## Despliegue en Railway

Sección de despliegue removida para restaurar la versión original.

